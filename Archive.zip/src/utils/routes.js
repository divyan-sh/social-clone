const routes = {
  ROOT: "/",
  SIGNIN: "/sign-in",
};

export default routes;
