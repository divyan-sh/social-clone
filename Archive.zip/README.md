# Module-1 (Login/SignUp)

> UI Part

1. Setup Routing (Layout,Outlet,Routes,Route) [completed]
2. HomePage [completed]
3. SignInPage [completed]
4. Auth Middleware to protect routes [completed]
5. Routes path constant variables

6. Sign in Page (2 column layout)
   - Gird from material UI (container, item, 12columns, item >> 12)
   - Sign In Form (TextFields)
   - Tab Layout (material ui)
   - Svg Background
